<?php
/**
 * @author  oke.ugwu
 */

return [
  'database' => [
    'host'     => '',
    'username' => '',
    'password' => '',
    'database' => ''
  ]
];
