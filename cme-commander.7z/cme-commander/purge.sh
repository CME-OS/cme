rm -f /etc/monit/conf.d/cme
apt-get purge monit php5-cli php5-mysqlnd

