rm -f /etc/monit/conf.d/cme
apt-get -y purge monit php5-cli php5-mysqlnd php5-mcrypt php5-curl curl

